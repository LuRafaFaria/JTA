﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace JTA
{
    public class Ammo : Sprite
    {
        //variables
        public List<Ammo> ammoPicked;
        public Vector2 origem;
        public float initialRotation;

        public Ammo(Game1 game, Vector2 position) : base(game, "ammo", width: 0.20f, collides: true)
        {
            this.game = game;
            origem = position;
            SetPosition(position);
            initialRotation = rotation;
            ammoPicked = new List<Ammo>();
        }

        public Ammo(Game1 game) : base(game)
        {
            this.game = game;
            origem = position;
            SetPosition(position);
            initialRotation = rotation;
            ammoPicked = new List<Ammo>();
        }

        public override void LateUpdate(GameTime gameTime)
        {
            foreach (Ammo ammo in game.scene.ammoList.ToArray())
            {
                if (ammo.collider.inCollision)
                {
                    foreach (Collider col in ammo.collider.collisions)
                    {
                        if (col.Tag == "Idle")
                        {
                            game.player.ammo += 15;
                            ammoPicked.Add(ammo);
                            game.cManager.Remove(ammo.collider);
                            game.scene.ammoList.Remove(ammo);
                        }
                    }
                }

            }

            base.LateUpdate(gameTime);
        }
    }
}
