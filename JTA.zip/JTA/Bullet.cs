﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace JTA
{
    public class Bullet : Sprite
    {
        private Vector2 origin;
        private Vector2 direction;
        private Vector2 oldPosition;
        private float oldRotation;
        private float rotation;

        const float speed = 5f;
        private bool end = false;
        public bool End => end;

        public Bullet(Game1 game, string name, float width = 0, float height = 0) : base(game, name, width, height, collides: true)
        {
        }

        public void Shoot(Vector2 direction, float rotation)
        {
            origin = position;
            this.direction = direction;

            SetRotation(rotation);

        }
        public override void Update(GameTime gameTime)
        {
            if ((origin - position).LengthSquared() >= 6 * 6)
            {
                end = true;
            }
            else
            {
                SetPosition(position + direction * speed * (float)gameTime.ElapsedGameTime.TotalSeconds);
            }

            oldPosition = position;
            oldRotation = rotation;

            if (collider.inCollision)
            {
                foreach (Collider col in collider.collisions)
                {

                    if (col.Tag == "unnamed")
                    {
                        end = true;
                    }
                }
            }

            base.Update(gameTime);
        }



    }
}
