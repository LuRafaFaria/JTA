﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JTA
{
    public class Button : Sprite
    {
        Game1 game;
        public Vector2 pos;
        public Rectangle buttonArea;
        Vector2 buttonSize;

        public Button(Game1 game, string name, Vector2 position, float width = 0, float height = 0) : base(game, name, width, height, collides: false)
        {
            this.game = game;
            SetPosition(position);
            pos = Camera.ToPixel(position) - Camera.ToLength(size) / 2f;
            buttonSize = Camera.ToLength(size);
            buttonArea = new Rectangle(pos.ToPoint(), buttonSize.ToPoint());


        }
        public Button(Game1 game) : base(game)
        {
            this.game = game;
            SetPosition(position);
            pos = Camera.ToPixel(position) - Camera.ToLength(size) / 2f;
            buttonSize = Camera.ToLength(size);
            buttonArea = new Rectangle(pos.ToPoint(), buttonSize.ToPoint());
        }



        public override void Update(GameTime gameTime)
        {

            foreach (Button button in game.control.pauseButtons)
            {
                switch (button.name)
                {
                    case "resume":
                        button.position = new Vector2(game.player.position.X, game.player.position.Y + 1);
                        break;
                    case "exit":
                        button.position = new Vector2(game.player.position.X, game.player.position.Y - 2);
                        break;
                }
            }
        }

    }
}
