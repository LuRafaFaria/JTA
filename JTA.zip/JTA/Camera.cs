﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JTA
{
    public class Camera
    {
        //Variaveis
        public static Camera instance;
        public Vector2 pixelSize; //Tamanho do foco da janela
        public Vector2 worldSize; //Tamanho do mundo (mapa)
        Vector2 ratio; //Ratio entre o mundo e o foco da janela
        Vector2 target; //Objeto que a câmera irá focar

        //Construtor
        public Camera(Game1 game, Vector2 worldSize)
        {
            pixelSize = new Vector2(game.GraphicsDevice.Viewport.Width, game.GraphicsDevice.Viewport.Height);
            initializeCamera(game, worldSize);
        }

        //Construtor caso receba um tamanho 0
        public Camera(Game1 game, float worldWidth = 0f, float worldHeight = 0f)
        {
            pixelSize = new Vector2(game.GraphicsDevice.Viewport.Width, game.GraphicsDevice.Viewport.Height);

            //Caso ambos os valores sejam 0
            if (worldWidth == 0 && worldHeight == 0)
            {
                throw new Exception("Camera cant have dimension of 0");
            }
            //Caso largura 0, calcular largura através da altura
            if (worldWidth == 0)
            {
                worldWidth = pixelSize.X * worldHeight / pixelSize.Y;
            }
            //Caso altura 0, calcular altura através da largura
            if (worldHeight == 0)
            {
                worldHeight = pixelSize.Y * worldWidth / pixelSize.X;
            }
            initializeCamera(game, new Vector2(worldWidth, worldHeight));

        }

        //Inicializar a câmera
        public void initializeCamera(Game1 game, Vector2 wdSize)
        {
            if (instance != null)
            {
                throw new Exception("Singleton already exists");
            }

            instance = this;
            worldSize = wdSize;
            ratio = pixelSize / worldSize;
            target = Vector2.Zero;
        }

        //Converter coordenadas do mundo para pixeis
        public static Vector2 ToPixel(Vector2 pos)
        {
            return new Vector2((pos.X - instance.target.X + instance.worldSize.X / 2f) * instance.ratio.X,
                                instance.pixelSize.Y - (pos.Y - instance.target.Y + instance.worldSize.Y / 2f) * instance.ratio.Y);
        }

        public static Vector2 ToLength(Vector2 length)
        {
            return length * instance.ratio;
        }

        //Focar a câmera num target
        public static void LookAt(Vector2 tgt)
        {
            instance.target = tgt;
        }
    }
}
