﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JTA
{
    public class CircleCollider : Collider
    {
        //variables
        internal float radius;


        public CircleCollider(Game1 game, string tag, Vector2 center, float radius) : base(game, tag)
        {
            position = center;
            this.radius = radius;
        }

        public override void Draw(GameTime gameTime)
        {
            if (debug)
            {
                Pixel.DrawCircle(position, radius, inCollision ? Color.Red : Color.DarkGreen);
            }
        }

        //O circulo rodado não tem qualquer diferença
        public override void Rotate(float theta)
        {
        }

    }
}
