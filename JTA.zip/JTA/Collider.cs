﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JTA
{
    public abstract class Collider
    {
        //variables
        protected Game1 game;
        protected bool debug;
        internal Vector2 position;
        internal bool inCollision;
        internal List<Collider> collisions;

        //Propriedades
        public string Tag
        {
            get; 
            private set;
        }

        protected Collider(Game1 game, string tag)
        {
            this.game = game;
            debug = false;
            collisions = new List<Collider>();
            Tag = tag;

            try 
            { 
               new Pixel(game); 
            }
            catch (Exception)
            {

            }
        }

        public void SetCollision(Collider col)
        {
            inCollision = true;
            collisions.Add(col);
        }

        public void ClearCollision()
        {
            inCollision = false;
            collisions.Clear();
        }

        //Recebe uma flag que liga que o debug
        public void SetDebug(bool flg)
        {
            debug = flg;
        }

        
        public virtual void SetPosition(Vector2 position)
        {
            this.position = position;
        }

        public abstract void Rotate(float theta);

        public abstract void Draw(GameTime gameTime);


    }
}
