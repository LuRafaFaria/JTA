﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace JTA
{
    public class ColliderAABB : Collider
    {
        //variables
        internal Rectangle bounds;

        //Construtor
        public ColliderAABB(Game1 game, string tag, Vector2 center, Vector2 size) : base(game, tag)
        {
            this.position = center;
            bounds = new Rectangle((center - size / 2f).ToPoint(), size.ToPoint());
        }

        public ColliderOBB GetOBB()
        {
            return new ColliderOBB(game, Tag, position, bounds.Size.ToVector2(), 0f);
        }

        public override void Draw(GameTime gameTime)
        {
            if (debug)
            {
                Pixel.DrawRectangle(bounds, inCollision ? Color.Red : Color.DarkGreen);
            }
        }

        public override void Rotate(float theta)
        {
            throw new Exception("AABB colliders cant rotate");
        }

        public override void SetPosition(Vector2 position)
        {
            this.position = position;
            bounds.Location = (position - (bounds.Size.ToVector2() / 2f)).ToPoint();
        }
    }
}
