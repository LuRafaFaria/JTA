﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace JTA
{
    public class ColliderOBB : Collider
    {
        internal float rotation;
        internal Vector2 extends;
        internal Vector2 orientation1;
        internal Vector2 orientation2 => new Vector2(-orientation1.Y, orientation1.X);


        public ColliderOBB(Game1 game, string tag, Vector2 center, Vector2 size, float rotation) : base(game, tag)
        {
            this.rotation = rotation;
            position = center;
            extends = size / 2f;
            GetOrientation();
        }

        public void GetOrientation()
        {
            orientation1 = new Vector2((float)Math.Cos(rotation), -(float)(Math.Sin(rotation)));
        }

        public override void Draw(GameTime gameTime)
        {
            if (debug)
            {
                Vector2 point1 = position + orientation1 * extends.X + orientation2 * extends.Y;
                Vector2 point2 = position + orientation1 * extends.X - orientation2 * extends.Y;
                Vector2 point3 = position - orientation1 * extends.X + orientation2 * extends.Y;
                Vector2 point4 = position - orientation1 * extends.X - orientation2 * extends.Y;
                Color color = inCollision ? Color.Red : Color.DarkGreen;

                Pixel.DrawLine(point1, point2, color);
                Pixel.DrawLine(point1, point3, color);
                Pixel.DrawLine(point2, point4, color);
                Pixel.DrawLine(point3, point4, color);
            }
        }

        public override void Rotate(float rotation)
        {
            this.rotation = rotation;
            GetOrientation();
        }

    }
}
