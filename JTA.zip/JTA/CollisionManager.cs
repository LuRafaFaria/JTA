﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;

namespace JTA
{
    public class CollisionManager
    {
        List<Collider> colliders;

        //construtor
        public CollisionManager()
        {
            colliders = new List<Collider>();
        }

        //Adicionar colliders à lista
        public void Add(Collider col)
        {
            colliders.Add(col);
        }

        //Remover colliders da lista
        public void Remove(Collider col)
        {
            colliders.Remove(col);
        }


        public void Update(GameTime gameTime)
        {
            foreach (Collider collider in colliders)
            {
                collider.ClearCollision();
            }


            for (int i = 0; i < colliders.Count - 1; i++)
            {
                for (int j = i + 1; j < colliders.Count; j++)
                {
                    bool areColliding = false;

                    if (colliders[i] is CircleCollider c1 && colliders[j] is CircleCollider c2)
                    {
                        areColliding = CircleVsCircle(c1, c2);
                    }
                    else if (colliders[i] is ColliderAABB a1 && colliders[j] is ColliderAABB a2)
                    {
                        areColliding = AABBVsAABB(a1, a2);
                    }
                    else if (colliders[i] is ColliderAABB a3 && colliders[j] is CircleCollider c3)
                    {
                        areColliding = CircleVsAABB(c3, a3);
                    }
                    else if (colliders[i] is CircleCollider c4 && colliders[j] is ColliderAABB a4)
                    {
                        areColliding = CircleVsAABB(c4, a4);
                    }
                    else if (colliders[i] is ColliderOBB o1 && colliders[j] is ColliderOBB o2)
                    {
                        areColliding = OBBVsOBB(o1, o2);
                    }
                    else if (colliders[i] is ColliderOBB o3 && colliders[j] is CircleCollider c5)
                    {
                        areColliding = OBBVsCircle(o3, c5);
                    }
                    else if (colliders[i] is CircleCollider c6 && colliders[j] is ColliderOBB o4)
                    {
                        areColliding = OBBVsCircle(o4, c6);
                    }
                    else if (colliders[i] is ColliderOBB o5 && colliders[j] is ColliderAABB a5)
                    {
                        areColliding = OBBVsAABB(o5, a5);
                    }
                    else if (colliders[i] is ColliderAABB a6 && colliders[j] is ColliderOBB o6)
                    {
                        areColliding = OBBVsAABB(o6, a6);
                    }
                    else
                    {
                        Type t1 = colliders[i].GetType();
                        Type t2 = colliders[j].GetType();
                        throw new Exception($"No collision function defined for types {t1} and {t2}");
                    }

                    if (areColliding)
                    {
                        colliders[i].SetCollision(colliders[j]);
                        colliders[j].SetCollision(colliders[i]);
                    }

                }
            }
        }

        //Comparar dois colliders para ver se intersetam
        bool CircleVsCircle(CircleCollider c1, CircleCollider c2)
        {
            return (c1.position - c2.position).Length() <= c1.radius + c2.radius;
        }

        bool AABBVsAABB(ColliderAABB c1, ColliderAABB c2)
        {
            return c1.bounds.Intersects(c2.bounds);
        }

        bool CircleVsAABB(CircleCollider c1, ColliderAABB c2)
        {
            bool collision = c2.bounds.Contains(c1.position);
            // horizontal rectangle lines
            for (int x = c2.bounds.Left; !collision && x <= c2.bounds.Right; x++)
            {
                if ((c1.position - new Vector2(x, c2.bounds.Top)).Length() < c1.radius)
                {
                    collision = true;
                }

                // similar to above code, just more compact
                collision = collision || (c1.position - new Vector2(x, c2.bounds.Bottom)).Length() < c1.radius;

            }
            // vertical rectangle lines
            for (int y = c2.bounds.Top; !collision && y <= c2.bounds.Bottom; y++)
            {
                if ((c1.position - new Vector2(c2.bounds.Left, y)).Length() < c1.radius)
                {
                    collision = true;
                }
                if ((c1.position - new Vector2(c2.bounds.Right, y)).Length() < c1.radius)
                {
                    collision = true;
                }
            }

            return collision;
        }

        bool OBBVsOBB(ColliderOBB colA, ColliderOBB colB)
        {
            float ra, rb;
            float[,] R, AbsR;
            R = new float[2, 2];
            AbsR = new float[2, 2];

            //Percorrer a matriz
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    //Se i ou j for 0 usa-se o orientation1, senão usa-se o orientation2
                    R[i, j] = Vector2.Dot(i == 0 ? colA.orientation1 : colA.orientation2,
                                          j == 0 ? colB.orientation1 : colB.orientation2);
                }
            }

            //Verificar a distancia entre centros
            Vector2 t = colB.position - colA.position;

            t = new Vector2(Vector2.Dot(t, colA.orientation1),
                            Vector2.Dot(t, colA.orientation2));

            //Erro
            const float ERRO = 0.00001f;

            //Percorre a matriz
            for (int i = 0; i < 2; i++)
            {
                for (int j = 0; j < 2; j++)
                {
                    //Calcula o valor absoluto
                    AbsR[i, j] = Math.Abs(R[i, j]) + ERRO;
                }
            }

            //test axia L =a0 L = a1 L=a2
            for (int i = 0; i < 2; i++)
            {
                // e == extends 
                // e[0] == extends.X ..... e[1] == extends.Y
                // ra = colA.extends[i];
                ra = colA.extends.Pos(i);
                // rb = colB.extends[0] * AbsR[i][0] + colB.extends[1] * AbsR[i][1] + colB.extends[2] * AbsR[i][2];
                rb = colB.extends.Pos(0) * AbsR[i, 0] + colB.extends.Pos(1) * AbsR[i, 1];
                
                //Se a distância for maior não está em colisão
                if (Math.Abs(t.Pos(i)) > ra + rb)
                { 
                    return false; 
                }
            }

            // Test axes L = b0, L = Bb1, L = b2
            for (int i = 0; i < 2; i++)
            {
                ra = colA.extends.Pos(0) * AbsR[0, i] + colA.extends.Pos(1) * AbsR[1, i];
                rb = colB.extends.Pos(i);


                if (Math.Abs(t.Pos(0) * R[0, i] + t.Pos(1) * R[1, i]) > ra + rb)
                {
                    return false;
                }
            }

            return true;
        }

        public bool OBBVsAABB(ColliderOBB colO, ColliderAABB colA)
        {
            return OBBVsOBB(colO, colA.GetOBB());
        }

        bool OBBVsCircle(ColliderOBB colOBB, CircleCollider circle)
        {
            //Retorna o vetor mais proximo do centro do circulo
            Vector2 ponto = ClosestPointOBB(circle.position, colOBB);

            // Calcular a distância ao quadrado
            Vector2 dist = ponto - circle.position;
            return Vector2.Dot(dist, dist) <= circle.radius * circle.radius;
        }


        //Retorna o vetor mais proxi
        private Vector2 ClosestPointOBB(Vector2 point, ColliderOBB colOBB)
        {
            Vector2 d = point - colOBB.position;

            //q fica com o centro do collider
            Vector2 q = colOBB.position;

            for (int i = 0; i < 2; i++)
            {
                // ...project d onto that axis to get the distance
                // along the axis of d from the box center
                float dist = Vector2.Dot(d, i == 0 ? colOBB.orientation1 : colOBB.orientation2);
                // se a distância for maior, reduz para a caixa
                if (dist > colOBB.extends.Pos(i))
                {
                    dist = colOBB.extends.Pos(i);
                }

                // se a distância for menor, aumenta para a caixa
                if (dist < -colOBB.extends.Pos(i))
                {
                    dist = -colOBB.extends.Pos(i);
                }

                // Step that distance along the axis to get world coordinate
                q += dist * (i == 0 ? colOBB.orientation1 : colOBB.orientation2);
            }

            return q;
        }
    }
}
