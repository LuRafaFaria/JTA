﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Graphics;

namespace JTA
{
    public class Control : Sprite
    {
        Game1 game;
        private Vector2 mouseDirection;
        public List<Button> buttons;
        public List<Button> pauseButtons;

        public enum GameState
        {
            Menu,
            Play,
            Pause,
            Credits,
        }

        public GameState CurrentGameState = GameState.Menu;

        public Control(Game1 game) : base(game)
        {
            this.game = game;
            buttons = new List<Button>();
            pauseButtons = new List<Button>();
        }

    }
}

