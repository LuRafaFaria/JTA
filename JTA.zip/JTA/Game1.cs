﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using System.Collections.Generic;
using System;
using System.Text;

namespace JTA
{
    /// <summary>
    /// This is the main type for your game.
    /// </summary>
    public class Game1 : Game
    {
        //Variables
        public GraphicsDeviceManager graphics;
        SpriteBatch spriteBatch;
        public CollisionManager cManager;

        //Class variables
        public Zombies zombies;
        public Scientist scientist;
        public Player player;
        public Sprite map;
        public Sprite boat;
        public Sprite sprite;
        public Ammo ammo;
        public UI userInterface;
        Button button;

        //cenas, créditos...
        public Control control;
        public Scene scene;
        bool credits = false;
        internal float jtaY = 1000f;
        internal float jta1Y = 1150f;
        internal float jta2Y = 1300f;
        internal float jta3Y = 1450f;

        //sprites
        public string playerMode = "Idle";
        public float playerModeWidth = 0.4f;
        public string zombieMode = "zombieIdle";

        SpriteFont arial30;

        Vector2 currentPosition = Vector2.Zero;

        //Propriedades
        public string PlayerMode { get { return playerMode; }  set { playerMode = value; }}

        public float PlayerModeWidth { get { return playerModeWidth; }  set { playerModeWidth = value; }}

        public Camera Camera { get; private set;}

        public SpriteManager SpriteManager { get; private set; }

        //Construtor
        public Game1()
        {
            graphics = new GraphicsDeviceManager(this);
            Content.RootDirectory = "Content";
            IsMouseVisible = true;
        }

        /// <summary>
        /// Allows the game to perform any initialization it needs to before starting to run.
        /// This is where it can query for any required services and load any non-graphic
        /// related content.  Calling base.Initialize will enumerate through any components
        /// and initialize them as well.
        /// </summary>
        protected override void Initialize()
        {
            graphics.PreferredBackBufferWidth = 1280;
            graphics.PreferredBackBufferHeight = 720;
            graphics.ApplyChanges();

            Components.Add(new KeyboardManager(this));
            SpriteManager = new SpriteManager(this);

            Camera = new Camera(this, worldWidth: 25f);
            base.Initialize();
        }

        /// <summary>
        /// LoadContent will be called once per game and is the place to load
        /// all of your content.
        /// </summary>
        protected override void LoadContent()
        {
            //teste123
            // Create a new SpriteBatch, which can be used to draw textures.
            spriteBatch = new SpriteBatch(GraphicsDevice);
            cManager = new CollisionManager();

            SpriteManager.AddSprites("idle");
            SpriteManager.AddSprites("zombieIdle");
            SpriteManager.AddSprites("walking");
            SpriteManager.AddSprites("zombieWalking");
            SpriteManager.AddSprites("punch");
            SpriteManager.AddSprites("dying");
            SpriteManager.AddSprites("bodyguns");
            SpriteManager.AddSprites("bullet");
            SpriteManager.AddSprites("NGButton");
            SpriteManager.AddSprites("exit");
            SpriteManager.AddSprites("resume");
            SpriteManager.AddSprites("scientist");
            SpriteManager.AddSprites("boat");
            SpriteManager.AddSprites("ammo");
            SpriteManager.AddSprites("life");
            SpriteManager.AddSprites("credits");
            SpriteManager.AddSprites("jtalogo");
            SpriteManager.AddSprites("zombiedeath");

            scene = new Scene(this, "MainScene");

            arial30 = Content.Load<SpriteFont>("arial30");

            map = scene.mapa;
            boat = scene.boat;
            player = scene.player;
            zombies = scene.zombie;
            scientist = scene.scientist;
            ammo = scene.ammo;
            control = new Control(this);
            button = new Button(this);
            userInterface = new UI(this);

            sprite = new Sprite(this);
            //animWalk = new AnimationWalking(this);

            control.buttons.Add(new Button(this, "jtalogo", new Vector2(0, 4), width: 6f));
            control.buttons.Add(new Button(this, "NGButton", new Vector2(0, 1), width: 5f));
            control.buttons.Add(new Button(this, "credits", new Vector2(0, -2), width: 5f));
            control.buttons.Add(new Button(this, "exit", new Vector2(0, -5), width: 5f));

            control.pauseButtons.Add(new Button(this, "resume", new Vector2(0, 1), width: 5f));
            control.pauseButtons.Add(new Button(this, "exit", new Vector2(0, -2), width: 5f));

            userInterface.uiElements.Add(new UI(this, "life", new Vector2(0, 0), width: 1f));
            userInterface.uiElements.Add(new UI(this, "ammo", new Vector2(0, 0), width: 1.05f));
        }


        /// <summary>
        /// Allows the game to run logic such as updating the world,
        /// checking for collisions, gathering input, and playing audio.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Update(GameTime gameTime)
        {
            if (GamePad.GetState(PlayerIndex.One).Buttons.Back == ButtonState.Pressed)
                Exit();

            if (KeyboardManager.IsKeyGoingDown(Keys.Escape))
            {
                if (control.CurrentGameState == Control.GameState.Pause)
                {
                    control.CurrentGameState = Control.GameState.Play;
                }

                else if (control.CurrentGameState == Control.GameState.Play)
                {
                    control.CurrentGameState = Control.GameState.Pause;
                }

                else if (control.CurrentGameState == Control.GameState.Credits)
                {
                    control.CurrentGameState = Control.GameState.Menu;
                }

                else
                {
                    Exit();
                }
            }

            MouseState mouse = Mouse.GetState();
            Vector2 mousePosition = new Vector2(mouse.X, mouse.Y);

            cManager.Update(gameTime);
            control.Update(gameTime);

            switch (control.CurrentGameState)
            {
                case Control.GameState.Menu:

                    jtaY = 1000f;
                    jta1Y = 1150f;
                    jta2Y = 1300f;
                    jta3Y = 1450f;

                    userInterface.LateUpdate(gameTime);

                    foreach (var button in control.buttons)
                    {
                        //Console.WriteLine($"{ button.buttonArea} | {mousePosition}");
                        if (button.buttonArea.Contains(mousePosition))
                        {
                            if (mouse.LeftButton == ButtonState.Pressed)
                            {
                                switch (button.name)
                                {
                                    case "jtalogo":
                                        break;
                                    case "NGButton":
                                        control.CurrentGameState = Control.GameState.Play;
                                        break;
                                    case "credits":
                                        control.CurrentGameState = Control.GameState.Credits;
                                        break;
                                    case "exit":
                                        Exit();
                                        break;
                                }
                            }
                        }

                    }

                    break;

                case Control.GameState.Play:

                    Console.WriteLine(gameTime.IsRunningSlowly); 

                    foreach (Button button in control.buttons.ToArray())
                    {
                        control.buttons.Remove(button);
                    }

                    userInterface.Update(gameTime);
                    player.Update(gameTime);
                    player.LateUpdate(gameTime);
                    zombies.Update(gameTime);
                    zombies.LateUpdate(gameTime);
                    scientist.Update(gameTime);
                    scientist.LateUpdate(gameTime);
                    ammo.LateUpdate(gameTime);
                    break;
                case Control.GameState.Pause:

                    button.Update(gameTime);

                    foreach (var button in control.pauseButtons.ToArray())
                    {
                        if (button.buttonArea.Contains(mousePosition))
                        {
                            if (mouse.LeftButton == ButtonState.Pressed)
                            {
                                switch (button.name)
                                {
                                    case "resume":
                                        control.CurrentGameState = Control.GameState.Play;

                                        player.SetPosition(player.oldPosition);
                                        player.SetRotation(player.oldRotation);


                                        foreach (Zombies zombie in scene.zombieList)
                                        {
                                            zombie.SetPosition(zombie.oldPosition);
                                            zombie.SetRotation(zombie.oldRotation);
                                        }

                                        foreach (Ammo ammo in scene.ammoList)
                                        {
                                            ammo.SetPosition(ammo.position);
                                        }

                                        break;
                                    case "exit":
                                        Exit();
                                        break;
                                }
                            }
                        }

                    }
                    break;
                case Control.GameState.Credits:

                    if (jta3Y >= 300)
                    {
                        jtaY = jtaY - 5f;
                        jta1Y = jta1Y - 5f;
                        jta2Y = jta2Y - 5f;
                        jta3Y = jta3Y - 5f;
                    }
                    

                    if (KeyboardManager.IsKeyDown(Keys.Escape))
                    {
                        control.CurrentGameState = Control.GameState.Menu;
                    }
                    break;
            }


            base.Update(gameTime);
        }

        /// <summary>
        /// This is called when the game should draw itself.
        /// </summary>
        /// <param name="gameTime">Provides a snapshot of timing values.</param>
        protected override void Draw(GameTime gameTime)
        {

            switch (control.CurrentGameState)
            {
                case Control.GameState.Menu:
                    GraphicsDevice.Clear(Color.Black);
                    break;
                case Control.GameState.Play:
                    GraphicsDevice.Clear(Color.CornflowerBlue);
                    break;
                case Control.GameState.Pause:
                    GraphicsDevice.Clear(Color.Black);
                    break;
                case Control.GameState.Credits:
                    GraphicsDevice.Clear(Color.Black);
                    break;

            }


            spriteBatch.Begin(SpriteSortMode.FrontToBack);

            switch (control.CurrentGameState)
            {
                case Control.GameState.Menu:
                     foreach (Button button in control.buttons)
                     {
                        button.Draw(spriteBatch);
                     }
                    break;
                case Control.GameState.Play:
                    //Desenhar player
                    scene.Draw(gameTime);
                    player.Draw(spriteBatch);

                    foreach (UI uiElement in userInterface.uiElements)
                    {
                        uiElement.Draw(spriteBatch);
                    }

                    break;

                case Control.GameState.Pause:

                    foreach (Button button in control.pauseButtons)
                    {
                        button.Draw(spriteBatch);
                    }

                    break;
                case Control.GameState.Credits:
                    string jta = "JTA";
                    Vector2 jtaSize = arial30.MeasureString(jta);
                    Vector2 jtaScreenSize = new Vector2(graphics.PreferredBackBufferWidth, jtaY + graphics.PreferredBackBufferHeight);
                    Vector2 jtaTextPos = (jtaScreenSize - jtaSize) / 2f;
                    spriteBatch.DrawString(arial30, jta, jtaTextPos, Color.Yellow);

                    string jta1 = "Feito por:";
                    Vector2 jta1Size = arial30.MeasureString(jta1);
                    Vector2 jta1ScreenSize = new Vector2(graphics.PreferredBackBufferWidth, jta1Y + graphics.PreferredBackBufferHeight);
                    Vector2 jta1TextPos = (jta1ScreenSize - jta1Size) / 2f;
                    spriteBatch.DrawString(arial30, jta1, jta1TextPos, Color.Yellow);

                    string jta2 = "Rafael Ribeiro e Diogo Ribeiro";
                    Vector2 jta2Size = arial30.MeasureString(jta2);
                    Vector2 jta2ScreenSize = new Vector2(graphics.PreferredBackBufferWidth, jta2Y + graphics.PreferredBackBufferHeight);
                    Vector2 jta2TextPos = (jta2ScreenSize - jta2Size) / 2f;
                    spriteBatch.DrawString(arial30, jta2, jta2TextPos, Color.Yellow);

                    string jta3 = "EDJD - Tecnicas e Desenvolvimento de Jogos";
                    Vector2 jta3Size = arial30.MeasureString(jta3);
                    Vector2 jta3ScreenSize = new Vector2(graphics.PreferredBackBufferWidth, jta3Y + graphics.PreferredBackBufferHeight);
                    Vector2 jta3TextPos = (jta3ScreenSize - jta3Size) / 2f;
                    spriteBatch.DrawString(arial30, jta3, jta3TextPos, Color.Yellow);

                    break;
            }

            spriteBatch.End();

            base.Draw(gameTime);
        }
    }
}