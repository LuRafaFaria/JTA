﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;

namespace JTA
{
    public class KeyboardManager : GameComponent
    {
        //Variables
        internal enum KeyState { Up, Down, GoingUp, GoingDown }
        public static KeyboardManager instance;
        internal Dictionary<Keys, KeyActions> keyState;


        internal class KeyActions
        {
            internal KeyState state;
            internal Dictionary<KeyState, List<Action>> actions;
            internal KeyActions(KeyState initialState)
            {
                state = initialState;
                actions = new Dictionary<KeyState, List<Action>>();

                foreach (KeyState keyState in Enum.GetValues(typeof(KeyState)))
                {
                    actions[keyState] = new List<Action>();
                }

            }
        }

        public KeyboardManager(Game1 game) : base(game)
        {
            keyState = new Dictionary<Keys, KeyActions>();

            if (instance == null)
            {
                instance = this;
            }

            else
            {
                throw new System.Exception("Singleton already exists");
            }
        }


        public override void Update(GameTime gameTime)
        {

            //Obter as teclas premidas atualmente
            Keys[] keysPressed = Keyboard.GetState().GetPressedKeys();

            foreach (Keys key in keysPressed)
            {
                //Se a tecla estiver no dicionario alterar o estado
                if (keyState.ContainsKey(key))
                {
                    switch (keyState[key].state)
                    {
                        case KeyState.Up:
                        case KeyState.GoingUp:
                            keyState[key].state = KeyState.GoingDown;
                            break;
                        case KeyState.Down:
                        case KeyState.GoingDown:
                            keyState[key].state = KeyState.Down;
                            break;
                    }
                }
                //Se a tecla não estiver no adicionar
                else
                {
                    keyState[key] = new KeyActions(KeyState.GoingDown);
                }
            }

            //Obter agora as teclas não premidas atualmente
            foreach (Keys key in keyState.Keys.ToArray())
            {
                if (!keysPressed.Contains(key))
                {
                    switch (keyState[key].state)
                    {
                        case KeyState.Up:
                        case KeyState.GoingUp:
                            keyState[key].state = KeyState.Up;
                            break;
                        case KeyState.Down:
                        case KeyState.GoingDown:
                            keyState[key].state = KeyState.GoingUp;
                            break;
                    }
                }
            }

            //Eventos
            foreach (Keys key in keyState.Keys)
            {
                KeyState keyStateCurrent = keyState[key].state;

                foreach (Action action in keyState[key].actions[keyStateCurrent])
                {
                    action();
                }
            }

            base.Update(gameTime);
        }

        bool PIsKeyDown(Keys k)
        {
            return keyState.ContainsKey(k) && (keyState[k].state == KeyState.Down || keyState[k].state == KeyState.GoingDown);
        }
        bool PIsKeyUp(Keys k)
        {
            return !keyState.ContainsKey(k) || keyState[k].state == KeyState.Up || keyState[k].state == KeyState.GoingUp;
        }
        bool PIsKeyGoingDown(Keys k)
        {
            return keyState.ContainsKey(k) && keyState[k].state == KeyState.GoingDown;
        }
        bool PIsKeyGoingUp(Keys k)
        {
            return keyState.ContainsKey(k) && keyState[k].state == KeyState.GoingUp;
        }


        public static bool IsKeyDown(Keys k)
        {
            return instance.PIsKeyDown(k);
        }

        public static bool IsKeyGoingDown(Keys k)
        {
            return instance.PIsKeyGoingDown(k);
        }

        public static bool IsKeyUp(Keys k)
        {
            return instance.PIsKeyUp(k);
        }

        public static bool IsKeyGoingUp(Keys k)
        {
            return instance.PIsKeyGoingUp(k);
        }

        #region Actions
        public static void SetDownAction(Keys k, Action a)
        {
            instance.SetAction(KeyState.Down, k, a);
        }

        public static void SetGoingDownAction(Keys k, Action a)
        {
            instance.SetAction(KeyState.GoingDown, k, a);
        }

        public static void SetUpAction(Keys k, Action a)
        {
            instance.SetAction(KeyState.Up, k, a);
        }

        public static void SetGoingUpAction(Keys k, Action a)
        {
            instance.SetAction(KeyState.GoingUp, k, a);
        }


        internal void SetAction(KeyState ks, Keys key, Action a)
        {
            if (!keyState.ContainsKey(key))
            {
                keyState[key] = new KeyActions(KeyState.Up);
            }
            keyState[key].actions[ks].Add(a);
        }

        #endregion
    }
}
