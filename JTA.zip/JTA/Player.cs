﻿using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Design;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Audio;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Linq;
using System.Runtime.CompilerServices;
using System.Security.Cryptography.X509Certificates;
using System.Text;
using System.Threading.Tasks;
using System.Threading;

namespace JTA
{
    public class Player : Sprite
    {
        //Variables
        //Movimento, posição...
        float speedWalk = 0.04f;
        float speedRun = 0.06f;
        public Vector2 direction;
        float playerWidth = 0.5f;
        public Vector2 mouseDirection;
        public Vector2 bulletDirection;
        public Vector2 oldPosition;
        public float oldRotation;
        float initialRotation;
        Vector2 origem;
        bool isRunning = false;

        public Vector2 vectorPos;

        //Sprite
        string playerMode;

        //Jogo
        private List<Bullet> bullets;
        public bool alive = true;
        float health = 100f;
        public int score = 0;
        int highscore = 0;
        public int ammo = 50;
        public bool pause = false;
        public bool win = false;
        bool lose = false;

        //Tempo e animações
        float waitTime = 0f;
        float soundTime = 0f;
        float gunAnimationTime = 0f;
        float animationTimer = 0f;
        float healthRegen = 2f;
        int loopCount = 0;
        float matchTime = 0f;

        //animations
        string[] walkAnimation = { "Walking01", "Walking02", "Walking04", "Walking05" };
        bool playAnim = false;
        float walkTimer = 0f;
        float dieTimer = 0f;

        //Efeitos
        SoundEffect running;
        SoundEffect gunshot;
        SoundEffect deathSound;
        SoundEffect bite;

        //text
        SpriteFont arial;

      
        public Player(Game1 game) : base(game, game.playerMode, width: game.playerModeWidth, collides: true)
        {
            bullets = new List<Bullet>();
            origem = position;
            initialRotation = rotation;

            arial = game.Content.Load<SpriteFont>("arial");

            running = game.Content.Load<SoundEffect>("playerRunning");
            gunshot = game.Content.Load<SoundEffect>("Gunshot");
            deathSound = game.Content.Load<SoundEffect>("deathSound");
            bite = game.Content.Load<SoundEffect>("bite");
        }


        public override void LateUpdate(GameTime gameTime)
        {
            if (collider.inCollision)
            {
                foreach (Collider col in collider.collisions)
                {
                    if (col.Tag == "zombieIdle")
                    {
                        waitTime -= gameTime.DeltaTime();
                        if (waitTime <= 0)
                        {
                            bite.Play();
                            health -= 10f;
                            waitTime = 0.5f;
                        }
                    }

                    if (col.Tag == "unnamed")
                    {
                        SetPosition(oldPosition);
                    }

                }
               
            }

            base.LateUpdate(gameTime);
        }



        public override void Update(GameTime gameTime)
        {

            foreach (Bullet bullet in bullets.ToArray())
            {
                bullet.Update(gameTime);
                if (bullet.End)
                {
                    game.cManager.Remove(bullet.collider);
                    bullets.Remove(bullet); 
                }
            }

            if (pause == false)
            {
                matchTime += gameTime.DeltaTime();
                oldPosition = position;
                oldRotation = rotation;
                MouseState mouse = Mouse.GetState();
                Vector2 mousePosition = new Vector2(mouse.X, mouse.Y);

                mouseDirection = mousePosition - Camera.ToPixel(position);
                SetRotation((float)Math.Atan2(mouseDirection.Y, mouseDirection.X));

                direction = new Vector2((float)Math.Cos(rotation), (float)Math.Sin(rotation + (float)Math.PI));

                MouseState mState = Mouse.GetState();

                vectorPos = position;

                if (KeyboardManager.IsKeyDown(Keys.W))
                {
                    WalkAnimation(gameTime);

                    if (isRunning)
                    {
                        SetPosition(position += direction * speedRun);
                    }

                    else
                    {
                        SetPosition(position += direction * speedWalk);
                    }

                    soundTime -= gameTime.DeltaTime();
                    if (soundTime <= 0)
                    {
                        running.Play();
                        soundTime = 0.3f;
                    }
                }

                if (KeyboardManager.IsKeyDown(Keys.S))
                {
                    WalkAnimation(gameTime);

                    SetPosition(position -= direction * speedWalk);
                    soundTime -= gameTime.DeltaTime();
                    if (soundTime <= 0)
                    {
                        running.Play();
                        soundTime = 0.3f;
                    }
                }



                if (KeyboardManager.IsKeyGoingDown(Keys.Space))
                {

                    gunAnimationTime += gameTime.DeltaTime();

                    if (gunAnimationTime <= 0.5f)
                    {
                        UpdateSprite("BodyWithGun");

                    }

                    if (ammo > 0)
                    {
                        Vector2 pos = position + direction * size.Y / 2f;


                        Bullet bullet = new Bullet(game, name: "bullet", width: 0.5f);
                        bullet.SetPosition(pos);
                        bullet.Shoot(direction, rotation);
                        bullets.Add(bullet);
                        ammo -= 1;

                        gunshot.Play();
                    }
                   
                }

                if (health <= 0)
                {
                    Die();
                }
                
                else
                {
                    healthRegen -= gameTime.DeltaTime();

                    if (healthRegen <= 0)
                    {
                        if (health < 100)
                        {
                            health += 1;
                        }
                        healthRegen = 2f;
                    }
                }

                Camera.LookAt(position);

                if (score >= highscore)
                {
                    highscore = score;
                }

            }

        }

        void WalkAnimation(GameTime gameTime)
        {
            walkTimer += gameTime.DeltaTime();

            if (walkTimer > 0.15)
            {
                UpdateSprite(walkAnimation[loopCount]);
                loopCount = loopCount + 1;

                walkTimer = 0f;
                if (loopCount == 3)
                {
                    loopCount = 0;
                }
            }

        }

        public void Win()
        {
            win = true;
            pause = true;
        }

        void Die()
        {
            //Play death sound
            UpdateSprite("Dying02");
            deathSound.Play();

            pause = true;
            alive = false;
            //Perguntar se o jogador quer voltar a jogar
            //Se carregar no enter... dar restart
            //Restart();
        }

        public void Lose()
        {
            lose = true;
            pause = true;
        }

        void Restart()
        {
            UpdateSprite("Idle");

            alive = true;
            win = false;
            lose = false;
            SetPosition(origem);
            SetRotation(initialRotation);
            health = 100f;
            ammo = 25;
            score = 0;

            game.scientist.SetPosition(game.scientist.origem);
            game.scientist.SetRotation(game.scientist.initialRotation);

            foreach (Zombies z in game.zombies.zombiesKilled)
            {
                game.scene.zombieList.Add(new Zombies(game, z.origem));
            }

            foreach (Zombies zombies in game.scene.zombieList)
            {
                zombies.SetPosition(zombies.origem);
                zombies.SetRotation(zombies.initialRotation);
            }

            foreach (Ammo a in game.ammo.ammoPicked)
            {
                game.scene.ammoList.Add(new Ammo(game, a.origem));
            }

            foreach (Ammo ammo in game.scene.ammoList)
            {
                ammo.SetPosition(ammo.origem);
                ammo.SetRotation(ammo.initialRotation);
            }
            alive = true;
            pause = false;
        }


        public override void Draw(SpriteBatch spriteBatch)
        {
            base.Draw(spriteBatch);
            foreach (Sprite bullet in bullets)
            {
                bullet.Draw(spriteBatch);
            }

            spriteBatch.DrawString(arial, $"{health}", new Vector2(5, 15f), Color.LightSkyBlue);
            spriteBatch.DrawString(arial, $"{ammo}", new Vector2(5, 690), Color.LightSkyBlue);
            spriteBatch.DrawString(arial, $"Score: {score}", new Vector2(1160, 700), Color.Black);

            if (!alive)
            {
                //Lose
                string lose = "YOU DIED";
                Vector2 loSize = arial.MeasureString(lose);
                Vector2 loScreenSize = new Vector2(game.graphics.PreferredBackBufferWidth, game.graphics.PreferredBackBufferHeight);
                Vector2 loTextPos = (loScreenSize - loSize) / 2f;
                spriteBatch.DrawString(arial, lose, loTextPos, Color.Red);

                //Ask to play again
                string playagain = "PRESS ENTER TO PLAY AGAIN";
                Vector2 paSize = arial.MeasureString(playagain);
                Vector2 paScreenSize = new Vector2(game.graphics.PreferredBackBufferWidth, 50 + game.graphics.PreferredBackBufferHeight);
                Vector2 paTextPos = (paScreenSize - paSize) / 2f;
                spriteBatch.DrawString(arial, playagain, paTextPos, Color.Red);

                spriteBatch.DrawString(arial, $"Highscore: {highscore}", new Vector2(1000, 700), Color.Black);

                if (KeyboardManager.IsKeyDown(Keys.Enter))
                {
                    Restart();
                }
            }

            if (win)
            {

                string win = "YOU WON";
                Vector2 wSize = arial.MeasureString(win);
                Vector2 wScreenSize = new Vector2(game.graphics.PreferredBackBufferWidth,
                                                   game.graphics.PreferredBackBufferHeight);
                Vector2 wTextPos = (wScreenSize - wSize) / 2f;
                spriteBatch.DrawString(arial, win, wTextPos, Color.LightGreen);

                //Ask to play again
                string playagain = "PRESS ENTER TO PLAY AGAIN";
                Vector2 paSize = arial.MeasureString(playagain);
                Vector2 paScreenSize = new Vector2(game.graphics.PreferredBackBufferWidth,
                                                   50 + game.graphics.PreferredBackBufferHeight);
                Vector2 paTextPos = (paScreenSize - paSize) / 2f;
                spriteBatch.DrawString(arial, playagain, paTextPos, Color.LightGreen);

                spriteBatch.DrawString(arial, $"Highscore: {highscore}", new Vector2(1000, 700), Color.Black);

                if (KeyboardManager.IsKeyDown(Keys.Enter))
                {
                    Restart();
                }
            }

            if (lose)
            {
                string lose = "YOU LOST";
                Vector2 lSize = arial.MeasureString(lose);
                Vector2 lScreenSize = new Vector2(game.graphics.PreferredBackBufferWidth,
                                                   game.graphics.PreferredBackBufferHeight);
                Vector2 lTextPos = (lScreenSize - lSize) / 2f;
                spriteBatch.DrawString(arial, lose, lTextPos, Color.Red);

                string sc = "THE SCIENTIST HAS DIED";
                Vector2 scSize = arial.MeasureString(sc);
                Vector2 scScreenSize = new Vector2(game.graphics.PreferredBackBufferWidth,
                                                   50 + game.graphics.PreferredBackBufferHeight);
                Vector2 scTextPos = (scScreenSize - scSize) / 2f;
                spriteBatch.DrawString(arial, sc, scTextPos, Color.Red);

                //Ask to play again
                string playagain = "PRESS ENTER TO PLAY AGAIN";
                Vector2 paSize = arial.MeasureString(playagain);
                Vector2 paScreenSize = new Vector2(game.graphics.PreferredBackBufferWidth,
                                                   100 + game.graphics.PreferredBackBufferHeight);
                Vector2 paTextPos = (paScreenSize - paSize) / 2f;
                spriteBatch.DrawString(arial, playagain, paTextPos, Color.Red);

                spriteBatch.DrawString(arial, $"Highscore: {highscore}", new Vector2(1000, 700), Color.Black);

                if (KeyboardManager.IsKeyDown(Keys.Enter))
                {
                    Restart();
                }
            }

        }

    }
}