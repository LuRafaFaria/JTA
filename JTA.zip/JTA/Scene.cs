﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Newtonsoft.Json.Linq;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using System.Management.Instrumentation;

namespace JTA
{
    public class Scene
    {
        public string imageName;

        //listas
        List<Sprite> sprites;
        public List<Zombies> zombieList;
        public List<Ammo> ammoList;
        public List<Sprite> buildings;

        //class variables
        Game1 game;
        public Player player;
        public Zombies zombie;
        public Scientist scientist;
        public Ammo ammo;
        public Sprite mapa;
        public Sprite boat;
        public Sprite building;
        public Sprite end;
        SpriteBatch spriteBatch;

        const float DegToRad = (float)Math.PI / 180f;

        public Scene(Game1 game, string fileName)
        {
            this.game = game;
            sprites = new List<Sprite>();
            zombieList = new List<Zombies>();
            ammoList = new List<Ammo>();
            buildings = new List<Sprite>();

            spriteBatch = new SpriteBatch(game.GraphicsDevice);

            //Tive de pôr o caminho inteiro porque ia a outra pasta do content
            JObject json = JObject.Parse(File.ReadAllText($"C:/Users/luraf/source/repos/JTA/JTA/Content//JTA/scenes/{fileName}.dt"));
            imageName = json["sceneName"].Value<string>();

            foreach (JToken image in json["composite"]["sImages"])
            {
                imageName = image["imageName"].Value<string>();
                float x = image["x"]?.Value<float>() ?? 0f;
                float y = image["y"]?.Value<float>() ?? 0f;

                float rotat = DegToRad * (image["rotation"]?.Value<float>() ?? 0f);

                float scaleX = image["scaleX"]?.Value<float>() ?? 1f;
                float scaleY = image["scaleY"]?.Value<float>() ?? 1f;

                if (image["itemIdentifier"]?.Value<string>() == "Player")
                {
                    player = new Player(this.game);
                    player.SetPosition(new Vector2(x, y));
                    player.SetRotation(-rotat);
                }

                else if (image["itemIdentifier"]?.Value<string>() == "scientist")
                {
                    scientist = new Scientist(this.game, new Vector2(x, y));
                    scientist.SetRotation(-rotat);
                }

                else if (image["itemIdentifier"]?.Value<string>() == "zombie")
                {
                    zombie = new Zombies(this.game, new Vector2(x, y));
                    zombie.SetRotation(-rotat);
                    zombieList.Add(zombie);
                }

                else if (image["itemIdentifier"]?.Value<string>() == "ammo")
                {
                    ammo = new Ammo(this.game, new Vector2(x + 3.9f, y + 3.9f));
                    ammo.SetRotation(-rotat);
                    ammoList.Add(ammo);
                }

                else if (image["itemIdentifier"]?.Value<string>() == "mapa")
                {
                    mapa = new Sprite(this.game, imageName, width: 10.65f, height: 10.84f, scaleX, scaleY);
                    mapa.SetPosition(new Vector2(-16.50f, -18.84f));
                    mapa.SetRotation(-rotat);
                }

                else if (image["itemIdentifier"]?.Value<string>() == "building")
                {
                    building = new Sprite(this.game, imageName, width: 6.40f, height: 3.60f, scaleX, scaleY, collides: true);
                    building.SetPosition(new Vector2(x + 3.70f, y + 1.40f));
                    building.SetRotation(-rotat);
                    buildings.Add(building);

                    //5.18f
                    //-5.04f
                }

                else if (image["itemIdentifier"]?.Value<string>() == "end")
                {
                    end = new Sprite(this.game, imageName, width: 6.40f, height: 3.60f, scaleX, scaleY, collides: true);
                    end.SetPosition(new Vector2(x + 3.70f, y + 1.40f));
                    end.SetRotation(-rotat);

                    //5.18f
                    //-5.04f
                }

                else if (image["itemIdentifier"]?.Value<string>() == "boat")
                {
                    boat = new Sprite(this.game, imageName, width: 1.73f, height: 1.19f, scaleX, scaleY, collides: false);
                    boat.SetPosition(new Vector2(x + 1, y + 0.5f));
                    boat.SetRotation(-rotat);
                }

            }
        }

        public void Update(GameTime gameTime)
        {
            foreach (Sprite sprite in sprites.ToArray())
            {
                sprite.Update(gameTime);
            }
        }

        public void Remove(Sprite sprite)
        {
            if (sprite.collider != null)
            {
                game.cManager.Remove(sprite.collider);
            }
            sprites.Remove(sprite);
        }

        public void Draw(GameTime gameTime)
        {
            spriteBatch.Begin();

            foreach (Sprite building in buildings)
            {
                building.Draw(spriteBatch);
            }
            end.Draw(spriteBatch);

            mapa.Draw(spriteBatch);
            boat.Draw(spriteBatch);
            scientist.Draw(spriteBatch);

            foreach (Ammo ammo in ammoList)
            {
                ammo.Draw(spriteBatch);
            }

            foreach (Zombies zombie in zombieList)
            {
                zombie.Draw(spriteBatch);
            }

            spriteBatch.End();
        }
    }
}
