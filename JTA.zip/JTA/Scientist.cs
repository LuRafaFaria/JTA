﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Audio;

namespace JTA
{
    public class Scientist : Sprite
    {
        //movimento, posição...
        public Vector2 origem;
        public float initialRotation;
        public Vector2 oldPosition;
        public float oldRotation;
        float speedWalk = 0.04f;
        float distance;
        Vector2 scientistDirection;
        Vector2 direction;

        //jogo
        float shotTime = 0f;
        float woahTime = 0f;
        public int health = 100;
        public bool found = false;
        bool dead = false;
        bool shot = false;

        //áudio
        SoundEffect woah;
        SoundEffect deathSound;

        public Scientist(Game1 game, Vector2 position) : base(game, "scientist", width: game.PlayerModeWidth, collides: true)
        {
            this.game = game;
            origem = position;
            initialRotation = rotation;
            SetPosition(position);

            woah = game.Content.Load<SoundEffect>("woah");
            deathSound = game.Content.Load<SoundEffect>("deathSound");
        }

        public override void LateUpdate(GameTime gameTime)
        {
            if (collider.inCollision)
            {
                foreach (Collider col in collider.collisions)
                {
                    if (col.Tag == "bullet")
                    {
                        woah.Play();
                        game.player.Lose();
                    }

                    if (col.Tag == "unnamed")
                    {
                        SetPosition(oldPosition);
                    }

                    if (col.Tag == "win")
                    {
                        game.player.Win();
                    }
                }
            }
            base.LateUpdate(gameTime);
        }

        public override void Update(GameTime gameTime)
        {
            if (game.control.CurrentGameState == Control.GameState.Play)
            {
                distance = Math.Abs((float)(Math.Pow(position.X - game.player.position.X, 2) - Math.Pow(position.Y - game.player.position.Y, 2)));


                if (!dead)
                {
                    if (distance <= 5 && distance >= 1)
                    {
                        if (game.player.alive)
                        {
                            oldPosition = position;
                            oldRotation = rotation;

                            scientistDirection = Camera.ToPixel(game.player.position) - Camera.ToPixel(position);
                            rotation = (float)Math.Atan2(scientistDirection.Y, scientistDirection.X);
                            direction = new Vector2((float)Math.Cos(rotation), (float)Math.Sin(rotation + (float)Math.PI));

                            SetPosition(position += direction * speedWalk);
                            SetRotation(rotation);
                        }

                    }
                }
                if (health <= 0)
                {
                    deathSound.Play();
                    dead = true;
                    game.player.score -= 500;
                    game.cManager.Remove(collider);
                    game.scene.Remove(this);
                    game.player.Lose();

                }


            }

            base.Update(gameTime);
        }

    }
}
