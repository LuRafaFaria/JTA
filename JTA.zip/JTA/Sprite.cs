﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework.Media;
namespace JTA
{
    public class Sprite
    {
        //Variables
        internal Game1 game;
        internal string name;
        bool collides = false;
        int layerDepth;

        //Spritesheet
        internal Texture2D texture;
        public Rectangle bounds;
        public float rotation = 0f;
        internal Vector2 origin;
        internal float width;
        internal float height;

        //No jogo... metros
        public Vector2 position;
        internal Vector2 size;
        internal Camera camera;

        //Colliders
        internal ColliderOBB collider;
        
        public Sprite(Game1 game, string name, float width = 0, float height = 0, float scaleX = 0, float scaleY = 0, bool collides = false)
        {

            //initialize
            this.game = game;
            this.name = name;
            this.collides = collides;
            this.width = width;
            this.height = height;

            try
            {
                texture = game.SpriteManager.GetTexture(name);
                bounds = game.SpriteManager.GetBounds(name);
            }
            catch (Exception exception)
            {
                texture = game.Content.Load<Texture2D>(name);
                bounds = texture.Bounds;
            }

            origin = bounds.Size.ToVector2() / 2f;

            //Atirar exceção se não passar bounds ou se forem nulos
            if (scaleX == 0f && scaleY == 0f && width == 0f && height == 0f)
            {
                throw new Exception("Sprite needs real bounds");
            }

            if (scaleX > 0 && scaleY > 0)
            {
                width = scaleX * bounds.Width / 80f;
                height = scaleY * bounds.Height / 80f;
            }

            //Se receber altura, calcular largura
            if (width == 0f)
            {
                width = bounds.Width * height / bounds.Height;
            }

            //Se receber largura, calcular altura
            if (height == 0f)
            {
                height = bounds.Height * width / bounds.Width;
            }

            //guardar tamanho e posição
            size = new Vector2(width, height);
            position = new Vector2(0, 0);

            //guardar collider
            if (collides)
            {
                collider = new ColliderOBB(game, name, position, size, rotation);
                collider.SetDebug(false);
                game.cManager.Add(collider);
            }
        }

        public Sprite(Game1 game)
        {
            this.game = game;
        }

        public void UpdateSprite(string name)
        {
            texture = game.SpriteManager.GetTexture(name);
            bounds = game.SpriteManager.GetBounds(name);

            height = bounds.Height * width / bounds.Width;

            size = new Vector2(width, height) * 2;


        }

        public Texture2D GetTexture(string name, float width, float heigth, float scaleX, float scaleY)
        {
            texture = game.SpriteManager.GetTexture(name);

            size = new Vector2(width * scaleX, height *  scaleY);

            return texture;
        }


        public string GetSprite()
        {
            return name;
        }

        public Sprite ForceOrigin(Vector2 origem)
        {
            origin = origem;
            return this;
        }
        public Sprite SetPosition(Vector2 position)
        {
            this.position = position;
            collider?.SetPosition(position);
            return this;
        }

        public Sprite SetRotation(float rotation)
        {
            this.rotation = rotation;
            collider?.Rotate(rotation);
            return this;
        }


        public virtual void Draw(SpriteBatch spriteBatch)
        {
            spriteBatch.Draw(
                texture,
                new Rectangle(Camera.ToPixel(position).ToPoint(), Camera.ToLength(size).ToPoint()),
                bounds,
                Color.White,
                rotation,
                origin,
                SpriteEffects.None,
                0);

            collider?.Draw(null);
        }

        public virtual void Update(GameTime gameTime)
        {
        }
        public virtual void LateUpdate(GameTime gameTime)
        {
        }

    }
}
