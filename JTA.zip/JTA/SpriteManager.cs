﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.AccessControl;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Graphics;
using Newtonsoft.Json.Linq;

namespace JTA
{
    public class SpriteInfo
    {
        #region Propriedades
        public Rectangle bounds
        {
            get;
            private set;
        }

        public string fileName
        {
            get;
            private set;
        }

        #endregion

        //Construtor
        public SpriteInfo(string name, Point position, Point size)
        {
            fileName = name;
            bounds = new Rectangle(position, size);
        }

        
    }

    public class SpriteManager
    {
        //Variaveis
        Game game;
        Dictionary<string, Texture2D> textures;
        Dictionary<string, SpriteInfo> details;
        
        public SpriteManager(Game game)
        {
            this.game = game;
            textures = new Dictionary<string, Texture2D>();
            details = new Dictionary<string, SpriteInfo>();
        }

        public void AddSprites(string name)
        {
            if (textures.ContainsKey(name))
            {
                throw new Exception($"Loading existing spritesheet '{name}'");
            }

            textures[name] = game.Content.Load<Texture2D>(name);

            //Tive de pôr o caminho inteiro porque ia a outra pasta do content
            JObject jsonFile = JObject.Parse(File.ReadAllText($"C:/Users/luraf/source/repos/JTA/JTA/Content/{name}.json"));
            JObject frames = jsonFile["frames"] as JObject;

            foreach (JProperty property in frames.Properties())
            {
                JObject frame = property.Value["frame"] as JObject;
             
                //position: x, y, width, heightr
                int x = frame.GetValue("x").ToObject<int>();
                int y = frame.GetValue("y").ToObject<int>();
                int w = frame.GetValue("w").ToObject<int>();
                int h = frame.GetValue("h").ToObject<int>();
                string frameName = property.Name;

                SpriteInfo info = new SpriteInfo(name, new Point(x, y), new Point(w, h));

                if (details.ContainsKey(frameName))
                {
                    throw new Exception($"sprite name '{frameName}' already exists");
                }

                details[frameName] = info;
            }

        }

        public Texture2D GetTexture(string objectName)
        {
            //Confirmar se o nome do objeto ja existe no dicionário de detalhes
            if (details.ContainsKey(objectName) == false)
                throw new Exception($"No object with the name {objectName}");

            SpriteInfo info = details[objectName];
            string textureName = info.fileName;

            //Confirmar se o nome da textura ja existe no dicionário de texturas
            if (textures.ContainsKey(textureName) == false)
                throw new Exception($"No texture with the name {textureName}");

            return textures[textureName];
        }



        public Rectangle GetBounds(string objectName)
        {
            // Confirmar novamente se o nome do objeto já se encontra no dicionário de detalhes
            if (details.ContainsKey(objectName) == false)
                throw new Exception($"No object with the name {objectName}");

            SpriteInfo info = details[objectName];

            //Retorna um retângulo com seguintes parametros (x, y, width, height)
            return info.bounds;
        }


    }
}
