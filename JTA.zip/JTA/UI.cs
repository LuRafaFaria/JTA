﻿using System;
using System.Collections.Generic;
using Microsoft.Xna.Framework;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Microsoft.Xna.Framework.Graphics;

namespace JTA
{
    public class UI : Sprite
    {
        //variables
        Game1 game;
        public Vector2 pos;
        public Rectangle uiArea;
        Vector2 uiSize;
        public List<UI> uiElements;

        public UI(Game1 game, string name, Vector2 position, float width = 0, float height = 0) : base(game, name, width, height, collides: false)
        {
            this.game = game;
            SetPosition(position);
            pos = Camera.ToPixel(position) - Camera.ToLength(size) / 2f;
            uiSize = Camera.ToLength(size);
            uiArea = new Rectangle(pos.ToPoint(), uiSize.ToPoint());

            uiElements = new List<UI>();


        }

        public UI(Game1 game) : base(game)
        {
            this.game = game;
            SetPosition(position);
            pos = Camera.ToPixel(position) - Camera.ToLength(size) / 2f;
            uiSize = Camera.ToLength(size);
            uiArea = new Rectangle(pos.ToPoint(), uiSize.ToPoint());

            uiElements = new List<UI>();
        }


        public override void Update(GameTime gameTime)
        {
            foreach (var uiElement in uiElements)
            {
                switch (uiElement.name)
                {
                    case "life":
                        uiElement.SetPosition(new Vector2(game.player.position.X - 11, game.player.position.Y + 6.5f));

                        break;
                    case "ammo":
                        uiElement.SetPosition(new Vector2(game.player.position.X - 11.3f, game.player.position.Y - 6.4f));
                        break;
                }
            }
        }

    }
}
