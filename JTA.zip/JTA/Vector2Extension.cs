﻿using Microsoft.Xna.Framework;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JTA
{
    public static class Vector2Extension
    {
        //Aceder a uma coordenada de um vetor
        //Por exemplo um vetor a = new Vector2(5, 10)
        //a.Pos(0) retorna o primeiro ponto... 5
        //a.Pos(1) retorna o segundo ponto... 10
        public static float Pos(this Vector2 vector, int i)
        {
            return i == 0 ? vector.X : vector.Y;
        }
    }
}
