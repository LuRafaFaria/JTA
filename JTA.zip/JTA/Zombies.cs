﻿using Microsoft.Xna.Framework.Graphics;
using Microsoft.Xna.Framework;
using Microsoft.Xna.Framework.Input;
using Microsoft.Xna.Framework.Audio;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace JTA
{
    public class Zombies : Sprite
    {
        //Variables movimento, posição...
        float distance, xdistance, ydistance;
        float speedWalk = 0.045f;
        Vector2 zombieDirection;
        Vector2 direction;
        public Vector2 origem;
        public float initialRotation;
        public Vector2 oldPosition;
        public float oldRotation;

        //game variable
        Game1 game;

        //jogo
        float health = 100f;
        public List<Zombies> zombiesKilled;

        //tempo, animações...
        float waitTime = 0f;
        float walkTimer = 0f;
        int loopCount = 0;
        float animTimer = 0f;

        //animações
        string[] walkAnimation = { "zombieWalking1", "zombieWalking2", "zombieWalking3", "zombieWalking4" };

        //Propriedades

        public Zombies(Game1 game, Vector2 position) : base(game, game.zombieMode, width: game.PlayerModeWidth, collides: true)
        {
            this.game = game;
            origem = position;
            oldPosition = position;
            initialRotation = rotation;
            SetPosition(position);
            zombiesKilled = new List<Zombies>();

        }

        public Zombies(Game1 game) : base(game)
        {
            this.game = game;
            origem = position;
            oldPosition = position;
            initialRotation = rotation;
            SetPosition(position);
            zombiesKilled = new List<Zombies>();
        }

        public override void LateUpdate(GameTime gameTime)
        {

            foreach (Zombies zombie in game.scene.zombieList)
            {
                if (zombie.collider.inCollision)
                {
                    foreach (Collider col in zombie.collider.collisions)
                    {
                        if (col.Tag == "bullet")
                        {
                            waitTime -= gameTime.DeltaTime();
                            if (waitTime <= 0)
                            {
                                zombie.health -= 35f;
                                waitTime = 0.1f;
                            }
                        }

                        if (col.Tag == "unnamed")
                        {
                            zombie.SetPosition(zombie.oldPosition);
                        }
                    }
                }
            }

            base.LateUpdate(gameTime);
        }

        public override void Update(GameTime gameTime)
        {
            if (game.control.CurrentGameState == Control.GameState.Play)
            {

                foreach (Zombies zombie in game.scene.zombieList.ToArray())
                {
                    
                    zombie.distance = Math.Abs((float)(Math.Pow(zombie.position.X - game.player.position.X, 2) - Math.Pow(zombie.position.Y - game.player.position.Y, 2)));

                    if (zombie.distance <= 15)
                    {
                        zombie.WalkAnimation(gameTime);

                        zombie.oldPosition = zombie.position;
                        zombie.oldRotation = zombie.rotation;

                        if (game.player.alive)
                        {
                            zombieDirection = Camera.ToPixel(game.player.position) - Camera.ToPixel(zombie.position);
                            rotation = (float)Math.Atan2(zombieDirection.Y, zombieDirection.X);
                            direction = new Vector2((float)Math.Cos(rotation), (float)Math.Sin(rotation + (float)Math.PI));

                            zombie.SetPosition(zombie.position += direction * speedWalk);
                            zombie.SetRotation(rotation);



                        }
                    }

                    if (zombie.health <= 0)
                    {

                        zombie.animTimer += gameTime.DeltaTime();

                        if (zombie.animTimer <= 0.5f)
                        {
                            zombie.UpdateSprite("zombiedeath");
                        }

                        else
                        {
                            zombiesKilled.Add(zombie);
                            game.cManager.Remove(zombie.collider);
                            game.scene.zombieList.Remove(zombie);

                            game.player.score += 100;
                        }

                    }
                }
            }

            else
            {

            }
        }

        void WalkAnimation(GameTime gameTime)
        {
            walkTimer += gameTime.DeltaTime();

            if (walkTimer > 0.15)
            {
                UpdateSprite(walkAnimation[loopCount]);
                loopCount = loopCount + 1;

                walkTimer = 0f;
                if (loopCount == 3)
                {
                    loopCount = 0;
                }
            }
        }

    }
}
